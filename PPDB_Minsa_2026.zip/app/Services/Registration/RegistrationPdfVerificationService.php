<?php

namespace App\Services\Registration;

class RegistrationPdfVerificationService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
