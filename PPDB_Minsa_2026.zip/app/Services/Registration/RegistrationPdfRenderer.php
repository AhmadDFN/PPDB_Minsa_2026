<?php

namespace App\Services\Registration;

class RegistrationPdfRenderer
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
