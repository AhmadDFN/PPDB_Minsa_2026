<?php

namespace App\Exceptions;

class RegistrationPdfGenerationException
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
