<?php

namespace App\Actions\Registration;

class GenerateRegistrationPdfAction
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
