<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistrationPdfVerificationController extends Controller
{
    //
}
