<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'currentStep' => 1,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'currentStep' => 1,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $steps = [
        1 => ['label' => 'Biodata Siswa', 'route' => 'applicant.biodata.edit'],
        2 => ['label' => 'Alamat Domisili', 'route' => 'applicant.address.edit'],
        3 => ['label' => 'Orang Tua / Wali', 'route' => 'applicant.parents.edit'],
        4 => ['label' => 'Pendidikan Asal', 'route' => 'applicant.education.edit'],
        5 => ['label' => 'Pilihan Program', 'route' => 'applicant.program.edit'],
        6 => ['label' => 'Unggah Dokumen', 'route' => 'applicant.documents.index'],
        7 => ['label' => 'Tinjau & Kirim', 'route' => 'applicant.registration.review'],
    ];
?>

<div class="mb-8">
    <!-- Desktop Step Indicator -->
    <nav aria-label="Progress" class="hidden sm:block">
        <ol class="flex items-center justify-between border border-neutral-200/80 rounded-2xl bg-white p-2 shadow-xs">
            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stepNum => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isCurrent = $currentStep === $stepNum;
                    $isPast = $currentStep > $stepNum;
                ?>
                <li class="relative flex-1 <?php echo e(!$loop->last ? 'pr-4' : ''); ?>">
                    <a
                        href="<?php echo e(route($step['route'])); ?>"
                        class="group flex items-center gap-3 p-2.5 rounded-xl transition <?php echo e($isCurrent ? 'bg-primary-50 text-primary-800 font-bold' : ($isPast ? 'text-neutral-700 hover:bg-neutral-50' : 'text-neutral-400 hover:text-neutral-600')); ?>"
                    >
                        <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs font-bold transition <?php echo e($isCurrent ? 'bg-primary-600 text-white shadow-xs' : ($isPast ? 'bg-secondary-600 text-white' : 'bg-neutral-100 text-neutral-500 border border-neutral-200')); ?>">
                            <?php if($isPast): ?>
                                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7" />
                                </svg>
                            <?php else: ?>
                                <?php echo e($stepNum); ?>

                            <?php endif; ?>
                        </span>
                        <span class="text-xs font-semibold truncate"><?php echo e($step['label']); ?></span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </nav>

    <!-- Mobile Step Indicator -->
    <div class="sm:hidden bg-white border border-neutral-200/80 rounded-xl p-4 shadow-xs">
        <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-bold text-primary-700 uppercase tracking-wider">
                Langkah <?php echo e($currentStep); ?> dari <?php echo e(count($steps)); ?>

            </span>
            <span class="text-xs font-bold text-neutral-800">
                <?php echo e($steps[$currentStep]['label'] ?? ''); ?>

            </span>
        </div>
        <div class="w-full bg-neutral-100 rounded-full h-2">
            <div class="bg-primary-600 h-2 rounded-full transition-all duration-300" style="width: <?php echo e(($currentStep / count($steps)) * 100); ?>%"></div>
        </div>
    </div>
</div>
<?php /**PATH D:\Dany\PPDB\PPDB_Minsa_2026\resources\views/components/applicant/form-steps.blade.php ENDPATH**/ ?>