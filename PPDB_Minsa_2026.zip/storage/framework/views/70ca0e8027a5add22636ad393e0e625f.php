<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'gray',
    'dot' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'gray',
    'dot' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $variantClasses = [
        'primary'   => 'badge-primary',
        'secondary' => 'badge-secondary',
        'accent'    => 'badge-accent',
        'success'   => 'badge-success',
        'warning'   => 'badge-warning',
        'danger'    => 'badge-danger',
        'info'      => 'badge-info',
        'gray'      => 'badge-gray',
    ][$variant] ?? 'badge-gray';

    $dotColors = [
        'primary'   => 'bg-primary-600',
        'secondary' => 'bg-secondary-600',
        'accent'    => 'bg-accent-500',
        'success'   => 'bg-green-600',
        'warning'   => 'bg-amber-600',
        'danger'    => 'bg-red-600',
        'info'      => 'bg-blue-600',
        'gray'      => 'bg-gray-400',
    ][$variant] ?? 'bg-gray-400';
?>

<span <?php echo e($attributes->merge(['class' => "badge {$variantClasses}"])); ?>>
    <?php if($dot): ?>
        <span class="w-1.5 h-1.5 rounded-full <?php echo e($dotColors); ?>"></span>
    <?php endif; ?>
    <?php echo e($slot); ?>

</span>

<?php /**PATH D:\Dany\PPDB\PPDB_Minsa_2026\resources\views/components/ui/badge.blade.php ENDPATH**/ ?>