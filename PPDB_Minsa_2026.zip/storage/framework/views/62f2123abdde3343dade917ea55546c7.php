<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Dokumen Persyaratan — PPDB MIN 1 Kota Madiun']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dokumen Persyaratan — PPDB MIN 1 Kota Madiun']); ?>
    <div class="max-w-5xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-6">
        <div>
            <a href="<?php echo e(route('applicant.dashboard')); ?>" class="inline-flex items-center gap-1.5 text-xs font-semibold text-primary-600 hover:text-primary-700 hover:underline mb-2">
                &larr; Kembali ke Dasbor
            </a>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-neutral-800 tracking-tight">Dokumen Persyaratan</h1>
            <p class="mt-1 text-sm text-neutral-600">Berkas disimpan secara privat dan hanya dapat diakses oleh pemilik akun.</p>
        </div>

        <?php if (isset($component)) { $__componentOriginal7d3a51f13009b8f6a21288c43418e500 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d3a51f13009b8f6a21288c43418e500 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.applicant.form-steps','data' => ['currentStep' => 6]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('applicant.form-steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentStep' => 6]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d3a51f13009b8f6a21288c43418e500)): ?>
<?php $attributes = $__attributesOriginal7d3a51f13009b8f6a21288c43418e500; ?>
<?php unset($__attributesOriginal7d3a51f13009b8f6a21288c43418e500); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d3a51f13009b8f6a21288c43418e500)): ?>
<?php $component = $__componentOriginal7d3a51f13009b8f6a21288c43418e500; ?>
<?php unset($__componentOriginal7d3a51f13009b8f6a21288c43418e500); ?>
<?php endif; ?>

        <?php if(session('success')): ?>
            <?php if (isset($component)) { $__componentOriginal746de018ded8594083eb43be3f1332e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal746de018ded8594083eb43be3f1332e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alert','data' => ['type' => 'success','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','dismissible' => true]); ?><?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $attributes = $__attributesOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__attributesOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $component = $__componentOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__componentOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php if (isset($component)) { $__componentOriginal746de018ded8594083eb43be3f1332e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal746de018ded8594083eb43be3f1332e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?>
                <ul class="list-disc list-inside text-xs space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $attributes = $__attributesOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__attributesOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $component = $__componentOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__componentOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if(! $registration): ?>
            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-8 text-center border-amber-200 bg-amber-50/50']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-8 text-center border-amber-200 bg-amber-50/50']); ?>
                <h2 class="text-lg font-bold text-neutral-800">Pilih Program Terlebih Dahulu</h2>
                <p class="text-sm text-neutral-600 max-w-xl mx-auto mt-2">
                    Persyaratan dokumen tersedia setelah Anda memilih program pada periode pendaftaran aktif.
                </p>
                <a href="<?php echo e(route('applicant.program.edit')); ?>" class="btn btn-primary inline-flex mt-5">Pilih Program</a>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
        <?php elseif($requirements->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-8 text-center border-amber-200 bg-amber-50/50']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-8 text-center border-amber-200 bg-amber-50/50']); ?>
                <h2 class="text-lg font-bold text-neutral-800">Persyaratan Belum Tersedia</h2>
                <p class="text-sm text-neutral-600 max-w-xl mx-auto mt-2">
                    Persyaratan dokumen untuk periode ini belum dikonfigurasi. Silakan hubungi panitia PPDB.
                </p>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5 sm:p-6 border-primary-200 bg-primary-50/30']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5 sm:p-6 border-primary-200 bg-primary-50/30']); ?>
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                        <h2 class="font-bold text-neutral-800"><?php echo e($registration->admissionPeriod?->name); ?></h2>
                        <p class="text-xs text-neutral-600 mt-1">
                            Kelengkapan dokumen wajib:
                            <strong><?php echo e($completeness['uploaded_count']); ?> / <?php echo e($completeness['required_count']); ?></strong>
                        </p>
                    </div>
                    <span class="text-xl font-extrabold <?php echo e($completeness['is_complete'] ? 'text-green-700' : 'text-primary-700'); ?>">
                        <?php echo e($completeness['percentage']); ?>%
                    </span>
                </div>
                <div class="w-full bg-neutral-200 rounded-full h-2.5 overflow-hidden mt-4">
                    <div class="h-full rounded-full <?php echo e($completeness['is_complete'] ? 'bg-green-500' : 'bg-primary-600'); ?>" style="width: <?php echo e($completeness['percentage']); ?>%"></div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <div class="space-y-5">
                <?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $document = $documents->get($requirement->id);
                        $effectiveMaxSizeKb = min($globalMaxSizeKb, (int) $requirement->max_size_kb);
                    ?>

                    <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5 sm:p-6 border-neutral-200/90']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5 sm:p-6 border-neutral-200/90']); ?>
                        <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                            <div>
                                <div class="flex items-center gap-2 flex-wrap">
                                    <h2 class="text-base font-bold text-neutral-800"><?php echo e($requirement->name); ?></h2>
                                    <?php if($requirement->is_required): ?>
                                        <span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-red-700">Wajib</span>
                                    <?php else: ?>
                                        <span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-neutral-100 text-neutral-600">Opsional</span>
                                    <?php endif; ?>
                                </div>
                                <?php if($requirement->description): ?>
                                    <p class="text-sm text-neutral-600 mt-1"><?php echo e($requirement->description); ?></p>
                                <?php endif; ?>
                                <p class="text-xs text-neutral-500 mt-2">
                                    Format: <?php echo e(str_replace(',', ', ', $requirement->allowed_mimes)); ?>

                                    &bull; Maksimum <?php echo e($effectiveMaxSizeKb); ?> KB
                                </p>
                            </div>

                            <?php if($document): ?>
                                <span class="inline-flex shrink-0 px-2.5 py-1 rounded-full text-xs font-bold bg-green-100 text-green-800">Sudah Diunggah</span>
                            <?php else: ?>
                                <span class="inline-flex shrink-0 px-2.5 py-1 rounded-full text-xs font-bold <?php echo e($requirement->is_required ? 'bg-amber-100 text-amber-800' : 'bg-neutral-100 text-neutral-600'); ?>">
                                    <?php echo e($requirement->is_required ? 'Belum Diunggah' : 'Belum Ada'); ?>

                                </span>
                            <?php endif; ?>
                        </div>

                        <?php if($document): ?>
                            <div class="mt-4 p-4 rounded-xl bg-neutral-50 border border-neutral-200">
                                <p class="text-sm font-semibold text-neutral-800 break-all"><?php echo e($document->original_name); ?></p>
                                <p class="text-xs text-neutral-500 mt-1">
                                    <?php echo e(number_format($document->file_size_bytes / 1024, 1)); ?> KB
                                    &bull; Diunggah <?php echo e($document->uploaded_at?->format('d-m-Y H:i')); ?>

                                </p>
                                <div class="flex flex-wrap gap-3 mt-3">
                                    <a href="<?php echo e(route('applicant.documents.preview', $document->id)); ?>" target="_blank" rel="noopener" class="text-xs font-semibold text-primary-700 hover:underline">Pratinjau</a>
                                    <a href="<?php echo e(route('applicant.documents.download', $document->id)); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Unduh</a>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($canEdit): ?>
                            <form
                                method="POST"
                                action="<?php echo e(route('applicant.documents.upload', $requirement->id)); ?>"
                                enctype="multipart/form-data"
                                class="mt-4 space-y-3"
                            >
                                <?php echo csrf_field(); ?>
                                <label for="document-file-<?php echo e($requirement->id); ?>" class="block text-xs font-semibold text-neutral-700">
                                    <?php echo e($document ? 'Pilih berkas pengganti' : 'Pilih berkas'); ?>

                                    <?php if($requirement->is_required && ! $document): ?>
                                        <span class="text-red-600">*</span>
                                    <?php endif; ?>
                                </label>
                                <input
                                    id="document-file-<?php echo e($requirement->id); ?>"
                                    class="document-upload-input block w-full text-sm text-neutral-700 file:mr-3 file:rounded-lg file:border-0 file:bg-primary-50 file:px-4 file:py-2 file:text-xs file:font-semibold file:text-primary-700 hover:file:bg-primary-100"
                                    type="file"
                                    name="file"
                                    accept=".pdf,.jpg,.jpeg,.png"
                                    data-max-size-kb="<?php echo e($effectiveMaxSizeKb); ?>"
                                    <?php if($requirement->is_required && ! $document): ?> required <?php endif; ?>
                                >
                                <p class="document-upload-feedback text-xs text-neutral-500">
                                    Batas unggah <?php echo e($effectiveMaxSizeKb); ?> KB; maksimum global <?php echo e($globalMaxSizeKb); ?> KB.
                                    Pastikan jenis file dan isinya sesuai.
                                </p>

                                <?php if($document): ?>
                                    <label for="document-reason-<?php echo e($requirement->id); ?>" class="block text-xs font-semibold text-neutral-700">Alasan penggantian (opsional)</label>
                                    <input
                                        id="document-reason-<?php echo e($requirement->id); ?>"
                                        type="text"
                                        name="reason"
                                        maxlength="255"
                                        class="form-input w-full"
                                        placeholder="Contoh: memperbarui hasil pindai"
                                    >
                                <?php endif; ?>

                                <button type="submit" class="btn btn-primary inline-flex text-xs">
                                    <?php echo e($document ? 'Ganti Dokumen' : 'Unggah Dokumen'); ?>

                                </button>
                            </form>
                        <?php else: ?>
                            <p class="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
                                Perubahan dokumen terkunci karena periode pendaftaran tidak sedang dibuka.
                            </p>
                        <?php endif; ?>

                        <?php if($document && $document->revisions->isNotEmpty()): ?>
                            <details class="mt-5 border-t border-neutral-100 pt-4">
                                <summary class="cursor-pointer text-xs font-semibold text-neutral-700">
                                    Riwayat penggantian (<?php echo e($document->revisions->count()); ?>)
                                </summary>
                                <ol class="mt-3 space-y-3">
                                    <?php $__currentLoopData = $document->revisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="rounded-lg border border-neutral-200 p-3">
                                            <p class="text-xs font-semibold text-neutral-800 break-all"><?php echo e($revision->original_name); ?></p>
                                            <p class="text-[11px] text-neutral-500 mt-1">
                                                Revisi <?php echo e($revision->revision_number); ?>

                                                &bull; <?php echo e($revision->replaced_at?->format('d-m-Y H:i')); ?>

                                                &bull; <?php echo e($revision->reason); ?>

                                            </p>
                                            <div class="flex gap-3 mt-2">
                                                <a href="<?php echo e(route('applicant.documents.revisions.preview', [$document->id, $revision->id])); ?>" target="_blank" rel="noopener" class="text-xs font-semibold text-primary-700 hover:underline">Pratinjau</a>
                                                <a href="<?php echo e(route('applicant.documents.revisions.download', [$document->id, $revision->id])); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Unduh</a>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </details>
                        <?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        document.querySelectorAll('.document-upload-input').forEach((input) => {
            input.addEventListener('change', () => {
                const feedback = input.parentElement.querySelector('.document-upload-feedback');
                const file = input.files[0];
                const maxBytes = Number(input.dataset.maxSizeKb) * 1024;

                if (file && file.size > maxBytes) {
                    feedback.textContent = `Ukuran file melebihi batas ${input.dataset.maxSizeKb} KB.`;
                    feedback.classList.add('text-red-700');
                    input.setCustomValidity('Ukuran file melebihi batas yang ditentukan.');
                } else {
                    feedback.textContent = `Batas unggah ${input.dataset.maxSizeKb} KB; pastikan jenis file dan isinya sesuai.`;
                    feedback.classList.remove('text-red-700');
                    input.setCustomValidity('');
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\Dany\PPDB\PPDB_Minsa_2026\resources\views/applicant/documents/index.blade.php ENDPATH**/ ?>