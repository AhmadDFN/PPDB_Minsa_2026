<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'subtitle' => null,
    'footer' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'subtitle' => null,
    'footer' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'card overflow-hidden'])); ?>>
    <?php if($title || isset($header)): ?>
        <div class="card-header flex items-center justify-between">
            <?php if(isset($header)): ?>
                <?php echo e($header); ?>

            <?php else: ?>
                <div>
                    <h3 class="text-base font-semibold text-gray-900"><?php echo e($title); ?></h3>
                    <?php if($subtitle): ?>
                        <p class="text-xs text-gray-500 mt-0.5"><?php echo e($subtitle); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="card-body">
        <?php echo e($slot); ?>

    </div>

    <?php if($footer || isset($footerSlot)): ?>
        <div class="card-footer">
            <?php echo e($footer ?? $footerSlot); ?>

        </div>
    <?php endif; ?>
</div>

<?php /**PATH D:\Dany\PPDB\PPDB_Minsa_2026\resources\views/components/ui/card.blade.php ENDPATH**/ ?>