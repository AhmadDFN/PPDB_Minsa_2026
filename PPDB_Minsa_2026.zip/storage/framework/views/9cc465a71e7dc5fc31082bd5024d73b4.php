<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Tinjau Pendaftaran — PPDB MIN 1 Kota Madiun']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tinjau Pendaftaran — PPDB MIN 1 Kota Madiun']); ?>
    <div class="max-w-5xl mx-auto space-y-6 px-4 py-8 sm:px-6 lg:px-8">
        <div>
            <a href="<?php echo e(route('applicant.dashboard')); ?>" class="mb-2 inline-flex items-center gap-1.5 text-xs font-semibold text-primary-600 hover:text-primary-700 hover:underline">
                &larr; Kembali ke Dasbor
            </a>
            <h1 class="text-2xl font-extrabold tracking-tight text-neutral-800 sm:text-3xl">Tinjau Pendaftaran</h1>
            <p class="mt-1 text-sm text-neutral-600">Periksa kembali data sebelum mengirim pendaftaran secara resmi.</p>
        </div>

        <?php if (isset($component)) { $__componentOriginal7d3a51f13009b8f6a21288c43418e500 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d3a51f13009b8f6a21288c43418e500 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.applicant.form-steps','data' => ['currentStep' => 7]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('applicant.form-steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentStep' => 7]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d3a51f13009b8f6a21288c43418e500)): ?>
<?php $attributes = $__attributesOriginal7d3a51f13009b8f6a21288c43418e500; ?>
<?php unset($__attributesOriginal7d3a51f13009b8f6a21288c43418e500); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d3a51f13009b8f6a21288c43418e500)): ?>
<?php $component = $__componentOriginal7d3a51f13009b8f6a21288c43418e500; ?>
<?php unset($__componentOriginal7d3a51f13009b8f6a21288c43418e500); ?>
<?php endif; ?>

        <?php if(session('success')): ?>
            <?php if (isset($component)) { $__componentOriginal746de018ded8594083eb43be3f1332e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal746de018ded8594083eb43be3f1332e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alert','data' => ['type' => 'success','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','dismissible' => true]); ?><?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $attributes = $__attributesOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__attributesOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $component = $__componentOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__componentOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php if (isset($component)) { $__componentOriginal746de018ded8594083eb43be3f1332e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal746de018ded8594083eb43be3f1332e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?>
                <ul class="list-inside list-disc space-y-1 text-xs">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $attributes = $__attributesOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__attributesOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $component = $__componentOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__componentOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($registration?->isSubmitted()): ?>
            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'border-green-200 bg-green-50/60 p-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'border-green-200 bg-green-50/60 p-6']); ?>
                <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                        <span class="inline-flex rounded-full bg-green-100 px-2.5 py-1 text-xs font-bold text-green-800">Pendaftaran Terkirim</span>
                        <h2 class="mt-3 text-lg font-bold text-neutral-800">Pendaftaran Anda telah dikirim</h2>
                        <p class="mt-1 text-sm text-neutral-600">Ini adalah tanda bukti pendaftaran, bukan keputusan penerimaan.</p>
                    </div>
                    <div class="rounded-xl border border-green-200 bg-white px-4 py-3 sm:text-right">
                        <p class="text-xs font-semibold text-neutral-500">Nomor Registrasi</p>
                        <p class="mt-1 break-all font-mono text-lg font-extrabold text-primary-800"><?php echo e($registration->registration_number); ?></p>
                    </div>
                </div>
                <dl class="mt-5 grid gap-4 border-t border-green-200 pt-4 text-sm sm:grid-cols-3">
                    <div>
                        <dt class="text-xs text-neutral-500">Nama calon siswa</dt>
                        <dd class="mt-1 font-semibold text-neutral-800"><?php echo e($applicant->full_name); ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-neutral-500">Program</dt>
                        <dd class="mt-1 font-semibold text-neutral-800"><?php echo e($program?->name ?? '—'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-neutral-500">Periode akademik</dt>
                        <dd class="mt-1 font-semibold text-neutral-800"><?php echo e($period?->academic_year ?? '—'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-neutral-500">Tanggal dan waktu pengiriman</dt>
                        <dd class="mt-1 font-semibold text-neutral-800"><?php echo e($registration->submitted_at?->translatedFormat('d F Y, H:i') ?? '—'); ?> WIB</dd>
                    </div>
                    <div>
                        <dt class="text-xs text-neutral-500">Status</dt>
                        <dd class="mt-1 font-semibold text-neutral-800"><?php echo e($registration->status->label()); ?></dd>
                    </div>
                </dl>
                <p class="mt-5 rounded-xl border border-blue-200 bg-blue-50 p-4 text-sm leading-relaxed text-blue-900">
                    Dokumen pendaftaran final untuk diunduh dan dicetak akan tersedia pada Fase 7. Setelah tersedia, cetak dokumen tersebut dan serahkan bersama dokumen fisik ke loket PTSP MIN 1 Kota Madiun.
                </p>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'border-primary-200 bg-primary-50/40 p-5 sm:p-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'border-primary-200 bg-primary-50/40 p-5 sm:p-6']); ?>
                <h2 class="text-base font-bold text-neutral-800">Ringkasan Kesiapan</h2>
                <p class="mt-1 text-sm text-neutral-600">Bagian yang belum lengkap harus diperbaiki sebelum formulir dapat dikirim.</p>
                <ul class="mt-4 grid gap-2 sm:grid-cols-2">
                    <?php $__currentLoopData = $readiness['sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-start gap-2 rounded-lg border <?php echo e($section['is_complete'] ? 'border-green-200 bg-white' : 'border-amber-200 bg-amber-50'); ?> p-3 text-sm">
                            <span class="font-bold <?php echo e($section['is_complete'] ? 'text-green-700' : 'text-amber-700'); ?>">
                                <?php echo e($section['is_complete'] ? '✓' : '!'); ?>

                            </span>
                            <span>
                                <span class="font-semibold text-neutral-800"><?php echo e($section['label']); ?></span>
                                <?php if(! $section['is_complete']): ?>
                                    <span class="mt-0.5 block text-xs text-neutral-600"><?php echo e(implode(', ', $section['missing'])); ?></span>
                                <?php endif; ?>
                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
        <?php endif; ?>

        <section class="grid gap-5 md:grid-cols-2">
            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Identitas Calon Siswa</h2>
                    <?php if($canEdit): ?>
                        <a href="<?php echo e(route('applicant.biodata.edit')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Ubah</a>
                    <?php endif; ?>
                </div>
                <dl class="mt-4 space-y-3 text-sm">
                    <div><dt class="text-xs text-neutral-500">Nama lengkap</dt><dd class="font-medium text-neutral-800"><?php echo e($applicant->full_name ?: 'Belum diisi'); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">NIK (tersamar)</dt><dd class="font-mono font-medium text-neutral-800"><?php echo e($maskedNik); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">Tempat, tanggal lahir</dt><dd class="font-medium text-neutral-800"><?php echo e($applicant->birth_place ?: '—'); ?>, <?php echo e($applicant->birth_date?->translatedFormat('d F Y') ?? '—'); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">Jenis kelamin</dt><dd class="font-medium text-neutral-800"><?php echo e($applicant->gender?->value === 'L' ? 'Laki-laki' : ($applicant->gender?->value === 'P' ? 'Perempuan' : '—')); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">NISN</dt><dd class="font-medium text-neutral-800"><?php echo e($applicant->nisn ?: '—'); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">Anak ke- / jumlah saudara</dt><dd class="font-medium text-neutral-800"><?php echo e($applicant->child_order ?? '—'); ?> / <?php echo e($applicant->siblings_count ?? '—'); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">Usia pada tanggal acuan periode</dt><dd class="font-medium text-neutral-800"><?php echo e($age['formatted'] ?? 'Belum dapat dihitung'); ?></dd></div>
                </dl>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Alamat Domisili</h2>
                    <?php if($canEdit): ?>
                        <a href="<?php echo e(route('applicant.address.edit')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Ubah</a>
                    <?php endif; ?>
                </div>
                <?php if($address): ?>
                    <p class="mt-4 text-sm leading-relaxed text-neutral-700"><?php echo e($address->full_address); ?></p>
                    <p class="mt-3 text-xs text-neutral-500">Jarak ke madrasah: <?php echo e($address->distance_to_school_km ?? '—'); ?> km</p>
                <?php else: ?>
                    <p class="mt-4 text-sm text-amber-700">Data alamat belum diisi.</p>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Data Ayah</h2>
                    <?php if($canEdit): ?>
                        <a href="<?php echo e(route('applicant.parents.edit')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Ubah</a>
                    <?php endif; ?>
                </div>
                <?php echo $__env->make('applicant.registration.partials.parent-summary', ['parent' => $father], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Data Ibu</h2>
                    <?php if($canEdit): ?>
                        <a href="<?php echo e(route('applicant.parents.edit')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Ubah</a>
                    <?php endif; ?>
                </div>
                <?php echo $__env->make('applicant.registration.partials.parent-summary', ['parent' => $mother], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Data Wali</h2>
                    <?php if($canEdit): ?>
                        <a href="<?php echo e(route('applicant.parents.edit')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Ubah</a>
                    <?php endif; ?>
                </div>
                <?php if($guardian): ?>
                    <?php echo $__env->make('applicant.registration.partials.parent-summary', ['parent' => $guardian], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <p class="mt-4 text-sm text-neutral-600">Tidak ada wali tambahan yang dicatat (opsional).</p>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Pendidikan Sebelumnya</h2>
                    <?php if($canEdit): ?>
                        <a href="<?php echo e(route('applicant.education.edit')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Ubah</a>
                    <?php endif; ?>
                </div>
                <?php if($education): ?>
                    <dl class="mt-4 space-y-3 text-sm">
                        <div><dt class="text-xs text-neutral-500">Jenjang</dt><dd class="font-medium text-neutral-800"><?php echo e(strtoupper($education->education_level?->value ?? '—')); ?></dd></div>
                        <div><dt class="text-xs text-neutral-500">Nama sekolah/lembaga</dt><dd class="font-medium text-neutral-800"><?php echo e($education->school_name ?: 'Tidak sekolah formal'); ?></dd></div>
                        <div><dt class="text-xs text-neutral-500">NPSN / Kota</dt><dd class="font-medium text-neutral-800"><?php echo e($education->npsn ?: '—'); ?> / <?php echo e($education->city ?: '—'); ?></dd></div>
                    </dl>
                <?php else: ?>
                    <p class="mt-4 text-sm text-amber-700">Riwayat pendidikan belum diisi.</p>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Program dan Periode</h2>
                    <?php if($canEditProgram): ?>
                        <a href="<?php echo e(route('applicant.program.edit')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Ubah</a>
                    <?php endif; ?>
                </div>
                <dl class="mt-4 space-y-3 text-sm">
                    <div><dt class="text-xs text-neutral-500">Program</dt><dd class="font-medium text-neutral-800"><?php echo e($program?->name ?? 'Belum dipilih'); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">Periode akademik</dt><dd class="font-medium text-neutral-800"><?php echo e($period?->academic_year ?? 'Belum tersedia'); ?></dd></div>
                    <div><dt class="text-xs text-neutral-500">Jadwal pendaftaran</dt><dd class="font-medium text-neutral-800"><?php echo e($period?->start_date?->translatedFormat('d F Y') ?? '—'); ?> s.d. <?php echo e($period?->end_date?->translatedFormat('d F Y') ?? '—'); ?></dd></div>
                </dl>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5 md:col-span-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5 md:col-span-2']); ?>
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-base font-bold text-neutral-800">Ringkasan Dokumen</h2>
                    <?php if($canEdit): ?>
                        <a href="<?php echo e(route('applicant.documents.index')); ?>" class="text-xs font-semibold text-primary-700 hover:underline">Kelola dokumen</a>
                    <?php endif; ?>
                </div>
                <?php if($documents->isEmpty()): ?>
                    <p class="mt-4 text-sm text-amber-700">Belum ada dokumen yang diunggah.</p>
                <?php else: ?>
                    <ul class="mt-4 divide-y divide-neutral-100">
                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex flex-col justify-between gap-1 py-3 text-sm sm:flex-row sm:items-center">
                                <span class="font-medium text-neutral-800"><?php echo e($document['requirement_name']); ?></span>
                                <span class="break-all text-xs text-neutral-600"><?php echo e($document['original_name']); ?> &middot; <?php echo e($document['uploaded_at']?->format('d-m-Y H:i')); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
        </section>

        <?php if(! $registration?->isSubmitted()): ?>
            <?php if($canSubmit): ?>
                <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'border-amber-300 bg-amber-50/60 p-5 sm:p-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'border-amber-300 bg-amber-50/60 p-5 sm:p-6']); ?>
                    <h2 class="text-base font-bold text-neutral-900">Pernyataan Orang Tua/Wali</h2>
                    <p class="mt-2 text-sm leading-relaxed text-neutral-700"><?php echo e($consentStatement); ?></p>
                    <p class="mt-1 text-xs text-neutral-500">Versi pernyataan: <?php echo e($consentVersion); ?></p>
                    <div class="mt-4 rounded-xl border border-amber-200 bg-white p-4 text-sm leading-relaxed text-amber-900">
                        <strong>Perhatian:</strong> Setelah tombol ditekan, pendaftaran akan berstatus SUBMITTED dan memperoleh nomor registrasi. Data masih dapat diperbarui selama periode pendaftaran terbuka, dan setiap perubahan akan dicatat.
                    </div>

                    <form method="POST" action="<?php echo e(route('applicant.registration.submit')); ?>" class="mt-5 space-y-4">
                        <?php echo csrf_field(); ?>
                        <label class="flex items-start gap-3 text-sm text-neutral-700">
                            <input type="checkbox" name="consent" value="1" class="mt-1 rounded border-neutral-300 text-primary-700 focus:ring-primary-600" required>
                            <span>Saya telah membaca pernyataan di atas dan menyetujuinya.</span>
                        </label>
                        <div>
                            <label for="consent-name" class="mb-1 block text-sm font-semibold text-neutral-700">Nama orang tua/wali yang menyetujui</label>
                            <input id="consent-name" type="text" name="consent_name" value="<?php echo e(old('consent_name')); ?>" maxlength="255" required class="form-input w-full sm:max-w-md">
                        </div>
                        <button type="submit" class="btn btn-primary inline-flex w-full justify-center font-semibold sm:w-auto">
                            Kirim Pendaftaran Final
                        </button>
                    </form>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
            <?php elseif($registration?->isDraft()): ?>
                <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'border-amber-200 bg-amber-50/60 p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'border-amber-200 bg-amber-50/60 p-5']); ?>
                    <h2 class="font-bold text-neutral-800">Pendaftaran Belum Siap Dikirim</h2>
                    <p class="mt-1 text-sm text-neutral-700">Lengkapi semua bagian pada daftar kesiapan sebelum mengirim pendaftaran.</p>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-5']); ?>
                    <p class="text-sm text-neutral-600">Pilih program pada periode pendaftaran yang sedang dibuka untuk memulai pendaftaran.</p>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\Dany\PPDB\PPDB_Minsa_2026\resources\views/applicant/registration/review.blade.php ENDPATH**/ ?>