<header class="bg-white/95 backdrop-blur-md border-b border-neutral-200/90 sticky top-0 z-50 transition-all duration-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20 gap-3">
            
            <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3 group select-none min-w-0">
                <div class="relative w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-secondary-700 via-secondary-600 to-primary-700 text-white flex items-center justify-center font-bold text-base sm:text-lg shadow-sm border border-secondary-800/20 shrink-0 transition-transform duration-200 group-hover:scale-[1.03]">
                    <span class="tracking-tight">M1</span>
                    <div class="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-accent-400 border-2 border-white flex items-center justify-center text-[7px] text-neutral-900 font-extrabold">
                        ✓
                    </div>
                </div>
                <div class="flex flex-col min-w-0">
                    <span class="text-[10px] sm:text-[11px] uppercase tracking-wider font-bold text-secondary-700 leading-tight truncate">
                        Kementerian Agama RI
                    </span>
                    <span class="text-sm sm:text-base md:text-lg font-extrabold text-neutral-900 tracking-tight group-hover:text-primary-700 transition-colors truncate">
                        MIN 1 Kota Madiun
                    </span>
                    <span class="text-[10px] sm:text-[11px] text-neutral-500 font-medium hidden sm:block leading-tight truncate">
                        Sistem Informasi Pendaftaran Peserta Didik Baru (PPDB)
                    </span>
                </div>
            </a>

            
            <nav class="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-semibold text-neutral-700 shrink-0" aria-label="Navigasi Utama">
                <a href="<?php echo e(url('/')); ?>" class="transition-colors hover:text-primary-600 <?php echo e(request()->is('/') ? 'text-primary-700 font-bold' : ''); ?>">
                    Beranda
                </a>
                <a href="<?php echo e(url('/#program')); ?>" class="transition-colors hover:text-primary-600">
                    Program Pendidikan
                </a>
                <a href="<?php echo e(url('/#alur')); ?>" class="transition-colors hover:text-primary-600">
                    Alur Pendaftaran
                </a>
                <a href="<?php echo e(url('/#ptsp')); ?>" class="transition-colors hover:text-primary-600">
                    Jadwal & Loket PTSP
                </a>
            </nav>

            
            <div class="hidden md:flex items-center gap-3 shrink-0">
                <?php if(auth()->guard()->check()): ?>
                    <a
                        href="<?php echo e(route('dashboard')); ?>"
                        class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider bg-primary-50 text-primary-700 hover:bg-primary-100 transition border border-primary-200 shadow-xs"
                    >
                        <svg class="w-4 h-4 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                        </svg>
                        <span>Dasbor Pendaftar</span>
                    </a>
                    <form method="POST" action="<?php echo e(auth()->user()->isAdmin() ? route('admin.logout') : route('logout')); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <button
                            type="submit"
                            class="px-2.5 py-2 text-xs font-semibold text-neutral-500 hover:text-red-600 transition"
                            title="Keluar dari sistem"
                        >
                            Keluar
                        </button>
                    </form>
                <?php else: ?>
                    <a
                        href="<?php echo e(route('login')); ?>"
                        class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-neutral-700 hover:text-primary-700 hover:bg-neutral-100/80 transition"
                    >
                        <svg class="w-4 h-4 text-neutral-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                        </svg>
                        <span>Masuk NIK</span>
                    </a>

                    <a
                        href="<?php echo e(route('register')); ?>"
                        class="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-primary-600 hover:bg-primary-700 shadow-md hover:shadow-lg transition-all duration-150 active:scale-[0.98]"
                    >
                        <span>Daftar Akun Baru</span>
                        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                    </a>
                <?php endif; ?>
            </div>

            
            <div class="flex md:hidden items-center shrink-0">
                <button
                    type="button"
                    id="mobile-menu-button"
                    class="p-2.5 rounded-xl text-neutral-800 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500 transition cursor-pointer select-none"
                    aria-label="Buka menu navigasi"
                    aria-expanded="false"
                    aria-controls="mobile-menu-panel"
                >
                    
                    <svg id="menu-open-icon" class="w-6 h-6 stroke-neutral-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                    
                    <svg id="menu-close-icon" class="w-6 h-6 stroke-neutral-800 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    
    <div
        id="mobile-menu-panel"
        class="hidden md:hidden border-t border-neutral-200/90 bg-white/98 backdrop-blur-md px-4 pt-3 pb-6 space-y-2 shadow-xl"
    >
        <a href="<?php echo e(url('/')); ?>" class="block px-3.5 py-2.5 rounded-xl text-sm font-semibold text-neutral-800 hover:bg-primary-50 hover:text-primary-700 transition">
            Beranda PPDB
        </a>
        <a href="<?php echo e(url('/#program')); ?>" class="block px-3.5 py-2.5 rounded-xl text-sm font-semibold text-neutral-800 hover:bg-primary-50 hover:text-primary-700 transition">
            Program Pendidikan (Unggulan & Reguler)
        </a>
        <a href="<?php echo e(url('/#alur')); ?>" class="block px-3.5 py-2.5 rounded-xl text-sm font-semibold text-neutral-800 hover:bg-primary-50 hover:text-primary-700 transition">
            Alur & Syarat Pendaftaran
        </a>
        <a href="<?php echo e(url('/#ptsp')); ?>" class="block px-3.5 py-2.5 rounded-xl text-sm font-semibold text-neutral-800 hover:bg-primary-50 hover:text-primary-700 transition">
            Jadwal & Loket PTSP
        </a>

        <div class="pt-4 border-t border-neutral-100 flex flex-col gap-2.5">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary w-full justify-center">
                    Buka Dasbor Pendaftar
                </a>
                <form method="POST" action="<?php echo e(auth()->user()->isAdmin() ? route('admin.logout') : route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline w-full justify-center text-red-600 border-red-200 hover:bg-red-50">
                        Keluar
                    </button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline w-full justify-center font-semibold">
                    Masuk Akun (NIK & Password)
                </a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary w-full justify-center font-semibold shadow-md">
                    Daftar Akun Calon Siswa
                </a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH D:\Dany\PPDB\PPDB_Minsa_2026\resources\views/components/navigation/public-navbar.blade.php ENDPATH**/ ?>