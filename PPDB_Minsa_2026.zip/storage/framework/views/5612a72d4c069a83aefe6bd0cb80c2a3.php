<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Langkah 4: Riwayat Pendidikan Asal — PPDB MIN 1 Kota Madiun']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Langkah 4: Riwayat Pendidikan Asal — PPDB MIN 1 Kota Madiun']); ?>
    <div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-6">
            <a href="<?php echo e(route('applicant.dashboard')); ?>" class="inline-flex items-center gap-1.5 text-xs font-semibold text-primary-600 hover:text-primary-700 hover:underline mb-2">
                &larr; Kembali ke Dasbor
            </a>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-neutral-800 tracking-tight">Riwayat Pendidikan Asal</h1>
            <p class="mt-1 text-sm text-neutral-600">Informasi pendidikan pra-sekolah (RA / TK / PAUD) yang pernah ditempuh oleh calon siswa.</p>
        </div>

        <!-- Step Indicator -->
        <?php if (isset($component)) { $__componentOriginal7d3a51f13009b8f6a21288c43418e500 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d3a51f13009b8f6a21288c43418e500 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.applicant.form-steps','data' => ['currentStep' => 4]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('applicant.form-steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentStep' => 4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d3a51f13009b8f6a21288c43418e500)): ?>
<?php $attributes = $__attributesOriginal7d3a51f13009b8f6a21288c43418e500; ?>
<?php unset($__attributesOriginal7d3a51f13009b8f6a21288c43418e500); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d3a51f13009b8f6a21288c43418e500)): ?>
<?php $component = $__componentOriginal7d3a51f13009b8f6a21288c43418e500; ?>
<?php unset($__componentOriginal7d3a51f13009b8f6a21288c43418e500); ?>
<?php endif; ?>

        <!-- Alerts -->
        <?php if(session('success')): ?>
            <div class="mb-6">
                <?php if (isset($component)) { $__componentOriginal746de018ded8594083eb43be3f1332e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal746de018ded8594083eb43be3f1332e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alert','data' => ['type' => 'success','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','dismissible' => true]); ?><?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $attributes = $__attributesOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__attributesOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $component = $__componentOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__componentOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'p-6 sm:p-8 border-neutral-200/80 shadow-md']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-6 sm:p-8 border-neutral-200/80 shadow-md']); ?>
            <?php
                $currentLevel = old('education_level', $education?->education_level?->value ?? ($education?->education_level ?? 'tk'));
            ?>

            <form method="POST" action="<?php echo e(route('applicant.education.update')); ?>" class="space-y-6" novalidate id="educationForm">
                <?php echo csrf_field(); ?>

                <!-- Pilihan Jenjang Pendidikan Sebelumnya -->
                <div>
                    <label class="block text-sm font-semibold text-neutral-800 mb-2">
                        Jenjang Pendidikan Anak Sebelumnya <span class="text-red-500 font-bold">*</span>
                    </label>
                    <p class="text-xs text-neutral-500 mb-3">Pilih jenjang sekolah pra-dasar yang pernah atau sedang diikuti.</p>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        <label class="flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition hover:bg-neutral-50 <?php echo e($currentLevel === 'ra' ? 'border-primary-500 bg-primary-50/30 ring-2 ring-primary-500/20' : 'border-neutral-200'); ?>">
                            <input
                                type="radio"
                                name="education_level"
                                value="ra"
                                class="text-primary-600 focus:ring-primary-500"
                                <?php echo e($currentLevel === 'ra' ? 'checked' : ''); ?>

                                onchange="toggleSchoolFields(this.value)"
                            />
                            <div>
                                <span class="block text-sm font-bold text-neutral-800">Raudhatul Athfal (RA)</span>
                                <span class="text-xs text-neutral-500">Pendidikan pra-dasar Kemenag</span>
                            </div>
                        </label>

                        <label class="flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition hover:bg-neutral-50 <?php echo e($currentLevel === 'tk' ? 'border-primary-500 bg-primary-50/30 ring-2 ring-primary-500/20' : 'border-neutral-200'); ?>">
                            <input
                                type="radio"
                                name="education_level"
                                value="tk"
                                class="text-primary-600 focus:ring-primary-500"
                                <?php echo e($currentLevel === 'tk' ? 'checked' : ''); ?>

                                onchange="toggleSchoolFields(this.value)"
                            />
                            <div>
                                <span class="block text-sm font-bold text-neutral-800">Taman Kanak-kanak (TK)</span>
                                <span class="text-xs text-neutral-500">Pendidikan pra-dasar Kemendikbud</span>
                            </div>
                        </label>

                        <label class="flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition hover:bg-neutral-50 <?php echo e($currentLevel === 'paud' ? 'border-primary-500 bg-primary-50/30 ring-2 ring-primary-500/20' : 'border-neutral-200'); ?>">
                            <input
                                type="radio"
                                name="education_level"
                                value="paud"
                                class="text-primary-600 focus:ring-primary-500"
                                <?php echo e($currentLevel === 'paud' ? 'checked' : ''); ?>

                                onchange="toggleSchoolFields(this.value)"
                            />
                            <div>
                                <span class="block text-sm font-bold text-neutral-800">PAUD / Kelompok Bermain</span>
                                <span class="text-xs text-neutral-500">Pendidikan anak usia dini</span>
                            </div>
                        </label>

                        <label class="flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition hover:bg-neutral-50 <?php echo e($currentLevel === 'other' ? 'border-primary-500 bg-primary-50/30 ring-2 ring-primary-500/20' : 'border-neutral-200'); ?>">
                            <input
                                type="radio"
                                name="education_level"
                                value="other"
                                class="text-primary-600 focus:ring-primary-500"
                                <?php echo e($currentLevel === 'other' ? 'checked' : ''); ?>

                                onchange="toggleSchoolFields(this.value)"
                            />
                            <div>
                                <span class="block text-sm font-bold text-neutral-800">Lainnya</span>
                                <span class="text-xs text-neutral-500">Homeschooling / Sanggar Belajar</span>
                            </div>
                        </label>

                        <label class="flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition hover:bg-neutral-50 <?php echo e($currentLevel === 'none' ? 'border-primary-500 bg-primary-50/30 ring-2 ring-primary-500/20' : 'border-neutral-200'); ?>">
                            <input
                                type="radio"
                                name="education_level"
                                value="none"
                                class="text-primary-600 focus:ring-primary-500"
                                <?php echo e($currentLevel === 'none' ? 'checked' : ''); ?>

                                onchange="toggleSchoolFields(this.value)"
                            />
                            <div>
                                <span class="block text-sm font-bold text-neutral-800">Tidak / Belum Sekolah</span>
                                <span class="text-xs text-neutral-500">Langsung mendaftar MI/SD</span>
                            </div>
                        </label>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal8515795c137f433faaa3099468a4ec61 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8515795c137f433faaa3099468a4ec61 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.error','data' => ['name' => 'education_level']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'education_level']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8515795c137f433faaa3099468a4ec61)): ?>
<?php $attributes = $__attributesOriginal8515795c137f433faaa3099468a4ec61; ?>
<?php unset($__attributesOriginal8515795c137f433faaa3099468a4ec61); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8515795c137f433faaa3099468a4ec61)): ?>
<?php $component = $__componentOriginal8515795c137f433faaa3099468a4ec61; ?>
<?php unset($__componentOriginal8515795c137f433faaa3099468a4ec61); ?>
<?php endif; ?>
                </div>

                <!-- Bagian Detail Sekolah Asal (Tersembunyi jika Tidak / Belum Sekolah) -->
                <div id="schoolDetailsSection" class="space-y-5 pt-4 border-t border-neutral-100 <?php echo e($currentLevel === 'none' ? 'hidden' : ''); ?>">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['name' => 'school_name','label' => 'Nama RA / TK / PAUD Asal','type' => 'text','placeholder' => 'Contoh: RA Perwanida 1 Kota Madiun','value' => old('school_name', $education?->school_name),'help' => 'Tuliskan nama lengkap lembaga pendidikan anak sebelumnya.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'school_name','label' => 'Nama RA / TK / PAUD Asal','type' => 'text','placeholder' => 'Contoh: RA Perwanida 1 Kota Madiun','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('school_name', $education?->school_name)),'help' => 'Tuliskan nama lengkap lembaga pendidikan anak sebelumnya.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['name' => 'npsn','label' => 'NPSN Sekolah Asal','type' => 'text','maxlength' => '10','placeholder' => 'Contoh: 69752310','value' => old('npsn', $education?->npsn),'help' => 'Nomor Pokok Sekolah Nasional (8 digit, opsional jika tidak tahu).']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'npsn','label' => 'NPSN Sekolah Asal','type' => 'text','maxlength' => '10','placeholder' => 'Contoh: 69752310','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('npsn', $education?->npsn)),'help' => 'Nomor Pokok Sekolah Nasional (8 digit, opsional jika tidak tahu).']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['name' => 'city','label' => 'Kota / Kabupaten Sekolah Asal','type' => 'text','placeholder' => 'Contoh: Kota Madiun','value' => old('city', $education?->city ?? 'Kota Madiun'),'help' => 'Kota atau Kabupaten tempat lembaga asal berada.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'city','label' => 'Kota / Kabupaten Sekolah Asal','type' => 'text','placeholder' => 'Contoh: Kota Madiun','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('city', $education?->city ?? 'Kota Madiun')),'help' => 'Kota atau Kabupaten tempat lembaga asal berada.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- Info Box saat Tidak Sekolah Dipilih -->
                <div id="noSchoolNotice" class="p-4 rounded-xl bg-neutral-50 border border-neutral-200 text-neutral-700 text-xs leading-relaxed <?php echo e($currentLevel === 'none' ? '' : 'hidden'); ?>">
                    <div class="flex items-start gap-2.5">
                        <svg class="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Calon siswa yang tidak menempuh pendidikan pra-sekolah formal tetap berhak mendaftar di MIN 1 Kota Madiun sesuai ketentuan usia penerimaan.</span>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="pt-6 border-t border-neutral-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <a href="<?php echo e(route('applicant.parents.edit')); ?>" class="btn btn-outline w-full sm:w-auto justify-center">
                        &larr; Sebelumnya: Orang Tua / Wali
                    </a>

                    <div class="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
                        <button type="submit" name="nav_action" value="save" class="btn btn-secondary w-full sm:w-auto justify-center font-semibold">
                            Simpan Perubahan
                        </button>
                        <button type="submit" name="nav_action" value="next" class="btn btn-primary w-full sm:w-auto justify-center font-semibold shadow-md">
                            Simpan & Lanjut ke Pilihan Program &rarr;
                        </button>
                    </div>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        function toggleSchoolFields(level) {
            const schoolSection = document.getElementById('schoolDetailsSection');
            const noSchoolNotice = document.getElementById('noSchoolNotice');
            const schoolNameInput = document.getElementById('school_name');

            if (level === 'none') {
                schoolSection.classList.add('hidden');
                noSchoolNotice.classList.remove('hidden');
                if (schoolNameInput) {
                    schoolNameInput.required = false;
                }
            } else {
                schoolSection.classList.remove('hidden');
                noSchoolNotice.classList.add('hidden');
                if (schoolNameInput) {
                    schoolNameInput.required = true;
                }
            }
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\Dany\PPDB\PPDB_Minsa_2026\resources\views/applicant/form/education.blade.php ENDPATH**/ ?>